-- Create the database
CREATE DATABASE library;

-- Use the database
USE library;

-- Create authors table
CREATE TABLE authors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    birth_date DATE
);

-- Create books table
CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    author_id INT,
    published_date DATE,
    FOREIGN KEY (author_id) REFERENCES authors(id)
);